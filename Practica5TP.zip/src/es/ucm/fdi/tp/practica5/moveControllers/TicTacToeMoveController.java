package es.ucm.fdi.tp.practica5.moveControllers;

@SuppressWarnings("serial")
public class TicTacToeMoveController extends ConnectNMoveController {
}
